import React from 'react'
import '../components/footer.css'

const Footer = () => {
    return (
        <>
            <div ClassName="container-fluid">
                <div className="row footer">
                    <div className="col-md-12 text-center">
                        <h3>Library Management System</h3>
                    </div>
                </div>

            </div>
        </>
    )
}

export default Footer;